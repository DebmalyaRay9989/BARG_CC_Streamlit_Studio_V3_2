"""Independent NumPy reference check of the stated equations, not the BARG-CC engine."""
import json
import numpy as np
from sklearn.cluster import KMeans
import sklearn
rng=np.random.default_rng(20261125)
max_drift_gap=0.; max_budget_excess=0.; min_floor_gap=1.; certs=affected_certs=affected_total=changed=total=0
trials=240
for t in range(trials):
    n=48; k=3; m=4; dim=5
    y=np.repeat(np.arange(k),n//k)
    floor=[.2,.1,.03,.001][t%4]
    kap=.5*np.log((1/floor-1)/(m-1))
    # Construct clearly separated reference clusters with varied noise, plus overlapping cases.
    centers=np.eye(dim)[y]
    blocks=np.stack([centers+rng.normal(0,[.02,.10,.85][t%3],(n,dim)) for _ in range(m)],axis=1)
    blocks/=np.linalg.norm(blocks,axis=-1,keepdims=True)
    mask=rng.random((n,m))>.25; mask[:,0]=True
    r=rng.random((n,m))
    w=mask*np.exp(kap*(2*r-1)); w/=w.sum(1,keepdims=True)
    min_floor_gap=min(min_floor_gap,float(w[mask].min()-floor))
    z=(np.sqrt(w)[...,None]*blocks).reshape(n,-1)
    if t%3==2:
        y=KMeans(n_clusters=k,n_init=5,random_state=t).fit_predict(z)
    c=np.stack([z[y==j].mean(0) for j in range(k)])
    dist=np.linalg.norm(z[:,None]-c[None,:],axis=2)
    # Enforce the theorem's nearest-centroid premise, rather than silently checking invalid partitions.
    assert np.all(dist.argmin(1)==y)
    q=np.zeros(n); post=mask.copy()
    for i in range(n):
        available=np.flatnonzero(mask[i]);
        if len(available)>1 and rng.random()<[.1,.4,.9][t%3]:
            v=rng.choice(available); post[i,v]=False; q[i]=w[i,v]
    wp=post*np.exp(kap*(2*r-1)); wp/=wp.sum(1,keepdims=True)
    zp=(np.sqrt(wp)[...,None]*blocks).reshape(n,-1)
    d=np.sqrt(2*q/(1+np.sqrt(1-q)))
    measured=np.linalg.norm(zp-z,axis=1)
    max_drift_gap=max(max_drift_gap,float(np.max(np.abs(measured-d))))
    cp=np.stack([zp[y==j].mean(0) for j in range(k)])
    B=np.array([d[y==j].mean() for j in range(k)])
    max_budget_excess=max(max_budget_excess,float(np.max(np.linalg.norm(cp-c,axis=1)-B)))
    gap=dist-dist[np.arange(n),y,None]-2*d[:,None]-B[y,None]-B[None,:]
    gap[np.arange(n),y]=np.inf
    certified=gap.min(1)>1e-10
    yp=np.linalg.norm(zp[:,None]-cp[None,:],axis=2).argmin(1)
    assert not np.any(certified & (yp!=y))
    certs+=int(certified.sum()); affected_certs+=int((certified & (q>0)).sum()); affected_total+=int((q>0).sum()); changed+=int((yp!=y).sum()); total+=n
assert max_drift_gap<1e-12 and max_budget_excess<1e-12 and min_floor_gap>=-1e-12
assert affected_certs>0 and changed>0
print(json.dumps({'scope':'Independent equation reference check; not a software-engine test or empirical benchmark','seed':20261125,'numpy':np.__version__,'scikit_learn':sklearn.__version__,'trials':trials,'record_trials':total,'affected_record_trials':affected_total,'certified':certs,'certified_affected':affected_certs,'changed':changed,'false_certificates':0,'max_drift_gap':max_drift_gap,'max_budget_excess':max_budget_excess,'min_floor_gap':min_floor_gap},indent=2))
