"""Audit saved pointwise outputs and sweep; requires Python standard library only."""
import csv, hashlib, json, math, sys
from pathlib import Path
root=Path(sys.argv[1] if len(sys.argv)>1 else Path(__file__).resolve().parents[1]).resolve()
def read(p):
    with p.open(encoding='utf-8-sig',newline='') as f: return list(csv.DictReader(f))
def boolean(x):
    assert x in ('True','False'),x
    return x=='True'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def check_pointwise(path,coverage):
    rows=read(path); ids=set(); out=[]; gaps=[]
    for r in rows:
        assert r['record'] not in ids; ids.add(r['record'])
        eligible,affected,cert,unchanged=map(lambda k:boolean(r[k]),('eligible','dropped','certified','unchanged'))
        q,d,measured,slack=map(lambda k:float(r[k]),('removed_mass','exact_drift','measured_drift','certificate_slack'))
        assert all(map(math.isfinite,(q,d,measured,slack)))
        assert 0<=q<1 and (q>0)==affected and (not affected or eligible)
        expected=math.sqrt(2*q/(1+math.sqrt(1-q)))
        assert math.isclose(d,expected,abs_tol=1e-10,rel_tol=1e-10)
        assert math.isclose(d,measured,abs_tol=1e-10,rel_tol=1e-10)
        assert cert==(slack>1e-10)
        assert unchanged==(r['original_cluster']==r['refitted_nearest_cluster'])
        assert not cert or unchanged
        gaps.append(abs(d-measured)); out.append((affected,cert,unchanged))
    stored={r['group']:r for r in read(coverage)}; groups={}
    for name,subset in [('All records',out),('View removed',[x for x in out if x[0]]),('No view removed',[x for x in out if not x[0]])]:
        n=len(subset); c=sum(x[1] for x in subset); u=sum(x[2] for x in subset); f=sum(x[1] and not x[2] for x in subset)
        a=stored[name]; assert int(a['n'])==n and int(a['false_certificates'])==f
        assert math.isclose(float(a['certified_pct']),100*c/n) and math.isclose(float(a['unchanged_pct']),100*u/n)
        groups[name]={'n':n,'certified':c,'unchanged':u,'false_certificates':f}
    return {'groups':groups,'max_drift_gap':max(gaps)}
v=root/'validation/public_commit_a213cd6'; files=list((v/'run1').glob('*.csv'))
assert len(files)==6 and all(sha(p)==sha(v/'run2'/p.name) for p in files)
a=json.loads((v/'run1/manifest.json').read_text()); b=json.loads((v/'run2/manifest.json').read_text())
assert type(a['baseline_reused']) is bool and type(b['baseline_reused']) is bool
assert {k:val for k,val in a.items() if k not in ('compute_seconds','wall_seconds')}=={k:val for k,val in b.items() if k not in ('compute_seconds','wall_seconds')}
sweep=read(root/'validation/certificate_firing/sweep.csv'); keys=set(); pooled={}
for r in sweep:
    key=(r['dataset'],float(r['floor']),int(r['seed'])); assert key not in keys; keys.add(key)
    n=int(r['affected']); c=int(r['cert_affected_n']); assert 0<=c<=n<=int(r['n'])
    assert int(r['false_cert'])==0 and math.isclose(float(r['cert_affected']),100*c/n)
    z=pooled.setdefault(f'{key[0]} | {key[1]:g}',[0,0]); z[0]+=c; z[1]+=n
assert len(keys)==60 and len(pooled)==12
assert sha(root/'paper/figures/workflow.png')==sha(root/'docs/figure_sources/workflow_v7_supplied.png')
report={'scope':'Archived outputs only; no BARG-CC engine execution or recomputation of centroid margins', 'digits':check_pointwise(root/'validation/digits_pointwise.csv',root/'validation/digits_coverage.csv'),'mixed_documents':check_pointwise(v/'run1/view_loss.csv',v/'run1/coverage.csv'),'identical_csv_pairs':len(files),'sweep_runs':len(keys),'sweep_false_certificates':0,'sweep_max_drift_gap':max(float(r['max_drift_gap']) for r in sweep),'pooled_counts':pooled,'figure1_sha256':sha(root/'paper/figures/workflow.png')}
print(json.dumps(report,indent=2))
