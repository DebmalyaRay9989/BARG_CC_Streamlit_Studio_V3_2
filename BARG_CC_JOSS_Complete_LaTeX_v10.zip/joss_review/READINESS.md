# JOSS pre-submission gate

| Review area | Evidence/status on 25 Nov 2026 | Required action |
|---|---|---|
| Paper structure and length | V10 contains all required headings; 1,665 whitespace-separated body tokens, excluding YAML and bibliography (includes markup/math). | Official renderer and author review. |
| Source target | Streamlit Studio V3.2 offline workflow; archived commit a213cd6be1955060bfb934526bad61492b52d024 plus patch. | Merge verified fixes, pin actual candidate. |
| Install and functionality | Archived 38/38 post-patch tests; archived two batch runs. | Rerun actual engine, install and CI on current source. |
| Pointwise/aggregate evidence | V8 check passed for 378 records, 60 sweep rows, six identical CSV pairs. | Publish authorized reproducibility artifacts; retain scope caveats. |
| Mathematical reference | V8 standalone check passed on 240 scenarios, 11,520 instances, 5,805 certified, 283 changed, zero false certificates. | Not an engine run or performance benchmark. |
| Public development | Archived history contains 12 commits, all dated 24 Nov 2026; live repo inaccessible in V8. | Provide genuine earlier public history of same software if available; otherwise develop openly for >6 months with meaningful activity. 24 May 2027 is only the six-month anniversary, not guaranteed eligibility. |
| License and redistribution | Live repository and license API inaccessible on 25 Nov 2026; archive does not establish a primary source license. MIT candidate and read-only verifier supplied. | Rights holders approve actual copyright notice and redistribution rights; publish root LICENSE, run verifier and confirm the candidate commit. |
| Research impact | Associated unpublished study and reproducible mechanism/diagnostic results. | Supply real research-use evidence; external adoption not established. |
| Packaging/docs/community | Integration guide and CI prepared, not installed. | Confirm install instructions, dependencies, usage examples, automated tests, contribution/support process in primary repository. |
| AI disclosure / authors / funding | No funding confirmed by submitting user on 25 Nov 2026 and manuscript updated; disclosure retained. | Both authors confirm final material, roles, rights, conflicts, tool history and funding declaration. |
| Official PDF | Local LaTeX/Pandoc compiled; official workflow supplied, not executed. | Run workflow and inspect artifact. |
| Software archive | Two author-supplied DOIs: Studio 10.5281/zenodo.24528136 and RAG 10.5281/zenodo.24528059. DOI and DataCite endpoints inaccessible during this revision. | Verify titles, creators, version-specific status, license, tag/commit and contents; final reviewed release must be archived after successful review. |

The public history is the principal unresolved editorial eligibility blocker. Do not backdate commits or confuse prior private development with public history. No score or acceptance guarantee is claimed. The V8 execution environment could not resolve GitHub and did not have Docker; no authenticated operations were performed.

V10 adds the supplied archive identifiers without claiming that the deposits contain the patched numerical source or establish six months of public development.
