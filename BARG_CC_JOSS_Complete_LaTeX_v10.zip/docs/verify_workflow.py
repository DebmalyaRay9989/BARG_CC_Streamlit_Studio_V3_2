"""Run after applying the supplied manifest fix, in the app's Python environment."""
from pathlib import Path
import json, os, subprocess, sys, tempfile

root = Path(sys.argv[1]).resolve()
env = dict(os.environ, OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1')
with tempfile.TemporaryDirectory() as tmp:
    dirs = [Path(tmp)/f'run{i}' for i in (1, 2)]
    for out in dirs:
        subprocess.run([sys.executable, 'run_batch.py', 'data/demo_mixed_documents.zip', '--output', str(out), '--profile', 'Research', '--gated', '--floor', '0.1', '--dropout', '1', '--seed', '17'], cwd=root, env=env, check=True)
        m = json.loads((out/'manifest.json').read_text(encoding='utf-8'))
        assert type(m['baseline_reused']) is bool
    csvs = sorted(dirs[0].glob('*.csv'))
    assert len(csvs) == 6
    assert all(p.read_bytes() == (dirs[1]/p.name).read_bytes() for p in csvs)
    import pandas as pd
    d = pd.read_csv(dirs[0]/'view_loss.csv')
    assert len(d) == 18 and d.dropped.sum() == 6
    assert not (d.certified & ~d.unchanged).any()
    print('PASS: JSON manifest and six repeatable CSV outputs')
subprocess.run([sys.executable,'-c',"from engine import digits_demo, coverage; from hamv_gate import strength_for_floor; d=digits_demo(strength_for_floor(.1,3),.1,17); assert len(d)==360; assert not (d.certified & ~d.unchanged).any(); assert abs(d.exact_drift-d.measured_drift).max()<1e-8; print(coverage(d).to_string(index=False)); print('PASS: Digits exact drift and certificate consistency')"],cwd=root,env=env,check=True)
