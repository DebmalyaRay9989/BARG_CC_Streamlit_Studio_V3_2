# Reproduce the review checks

Use the existing `BARG_CC_Streamlit_Studio_V3_2_2026.zip` supplied by the author. Its SHA-256 is in `validation/source_sha256.txt`. The original software archive is not redistributed here because its public licensing and third-party permissions are not established. Extract it into a fresh folder and work in its application root. Install its declared dependencies in an isolated Python environment. The observed test environment was Linux x86_64, Python 3.13.5, NumPy 2.3.5, pandas 2.2.3, SciPy 1.17.0 and scikit-learn 1.8.0. These are observed versions, not a claim that a fresh dependency installation was tested.

1. Run `python -m unittest discover -s tests -v` (38 tests passed in 2.173 s on the unmodified archive).
2. Run the original batch command below in a new output directory to reproduce the manifest bug. It completed numerical work but raised `TypeError: Object of type bool is not JSON serializable` under the observed NumPy version. A `numpy.bool_` is returned by the baseline reuse expression in `engine.py` when gating is enabled. No numerical changes are necessary.
3. Review `patch/manifest_boolean.patch` and replace the original `run_batch.py` with `patch/run_batch.py` (or apply the one-line diff). The local patch explicitly casts `baseline_reused` to a native Python bool before JSON serialization. No changes were made to the supplied ZIP or live repositories.
4. Run twice with distinct, empty output directories:

```sh
python run_batch.py data/demo_mixed_documents.zip --output review_run_1 --profile Research --gated --floor 0.1 --dropout 1 --seed 17
python run_batch.py data/demo_mixed_documents.zip --output review_run_2 --profile Research --gated --floor 0.1 --dropout 1 --seed 17
```

The forced dropout stress case removes one view from every eligible row, not from single-view rows. The observed outputs were 18 rows, 6 affected, selected K=4, 12 certified (all unaffected), all 18 unchanged. The six CSVs agreed byte-for-byte in this environment; timing fields in the manifests are not expected to agree. `verify_workflow.py` provides an executable regression check and reproduces the Digits fold with seed 17, dropout 0.1, floor 0.1. Run it by passing the patched application root. It creates temporary output directories and leaves the application source unchanged.

```sh
python /path/to/verify_workflow.py /path/to/BARG_CC_Streamlit_Studio_V3_2
```

The new checks are small verification examples, not a reproduction of the full manuscript experiments or validation of semantic quality. Full browser and RAG testing remain outstanding. The reference results in the manuscript archive are kept separate from the new execution evidence.

## Companion distribution (separate scope)
The PyPI package metadata and documented CLI are available at https://pypi.org/project/bargcc/0.1.1/ . A user with access to the public index can run `python -m pip install bargcc==0.1.1` followed by `bargcc certify --rho 0.1 --views 3`. In the final manuscript environment, an attempted no-dependency wheel download returned no matching distribution; the listing was independently retrieved, but installation and execution were not verified. This package is not the tested Streamlit batch backend.

## Final rerun
Fresh extraction of the same supplied ZIP: 38 regression tests passed (2.268 s); the local manifest patch was then applied and `verify_workflow.py` completed successfully. See `validation/final_regression.log` and `validation/final_workflow.log`. The earlier CSVs remain the recorded pointwise outputs, not newly exported files from the temporary-directory rerun.

## Selected-image revision (25 November 2026)
The fresh extraction and regression run passed all 38 tests in 2.304 s. After applying the same local patch, `verify_workflow.py` reproduced the batch and Digits consistency checks; see `validation/image_revision_regression.log` and `validation/image_revision_workflow.log`. The selected figure is unchanged from the provided image. Its conceptual output schema is qualified in the paper caption; the previous vector figure is retained only in `docs/vector_reference/`.

## Primary public source and additional companion repository (25 November 2026)
The primary public source candidate is https://github.com/DebmalyaRay9989/BARG_CC_Streamlit_Studio_V3_2 . Review the upstream manifest patch and run the verification against a pinned commit as described in `repository_handoff/INTEGRATE.md`. The earlier execution evidence applies to the supplied ZIP, not to a verified clone of current main. The Hugging Face code repository at https://huggingface.co/Debmalya/BARG_CC_HuggingFace_Space_Deployment_v2 is a separate research-workbench distribution; its structural checks and local neural workflow were not executed as part of the audit in this paper.

A fresh local archive extraction accepted the one-line patch using `git apply --check` and `git apply`. After patching, 38 regression tests passed (2.413 s), and the workflow verifier passed with the same six repeatable CSVs and Digits results. See `validation/repository_revision_regression.log` and `validation/repository_revision_workflow.log`. This does not establish current-public-commit equivalence.

## Public repository check (25 November 2026, revision 2)
```sh
git clone https://github.com/DebmalyaRay9989/BARG_CC_Streamlit_Studio_V3_2.git && cd BARG_CC_Streamlit_Studio_V3_2
git checkout a213cd6be1955060bfb934526bad61492b52d024
python -m venv .venv && . .venv/bin/activate && pip install -r requirements.txt
python -m unittest discover -s tests          # unmodified: 37 pass, 1 error (missing .streamlit/config.toml)
git apply /path/to/package/patch/public_repo_fixes.patch
python -m unittest discover -s tests          # 38 pass
python run_batch.py data/demo_mixed_documents.zip --output r1 --profile Research --gated --floor 0.1 --dropout 1 --seed 17
python run_batch.py data/demo_mixed_documents.zip --output r2 --profile Research --gated --floor 0.1 --dropout 1 --seed 17
python /path/to/package/validation/certificate_firing/run_sweep.py . sweep.csv
```
Observed environment: Python 3.13.18, NumPy 2.5.5, pandas 2.3.3, SciPy 1.18.1, scikit-learn 1.9.1, Streamlit 1.67.0.

## Revision 3 figure reproduction
From the manuscript-package root, run `python docs/figure_sources/build_figures.py` with pandas and matplotlib installed. This reads the archived 60-run sweep CSV, pools certified and affected counts per dataset and floor, and writes the figure assets and `docs/figure_sources/sweep_pooled.csv`. It does not rerun the scientific engine.

## Revision 4 figure reproduction
Run `python docs/figure_sources/prepare_selected_workflow.py` to apply deterministic label corrections to the archived selected raster. This recreates Figure 1, not an empirical result. Figure 2 remains generated from archived sweep counts.

## Revision 6 figure and archive reproduction
`python docs/figure_sources/prepare_selected_workflow.py` now copies the supplied V6 image without pixel modifications and wraps it in a PDF for LaTeX. The old editing script is retained as `prepare_workflow_v4_historical.py` for history. `python docs/figure_sources/build_figures.py` also rebuilds Figure 2 from the archived sweep. `python docs/verify_v6_archive.py` checks the stored image and CSV evidence without executing the numerical engine.

## Revision 7 image and archive verification

`python docs/figure_sources/prepare_selected_workflow.py` copies the exact new portrait image from `workflow_v7_supplied.png` and wraps it for the companion PDF. `python docs/verify_v7_archive.py` checks the image hash and existing sweep and CSV evidence. No numerical engine was executed for this revision. The source commit and patch are still required to reproduce the earlier software runs.

## Revision 8 (25 November 2026)
From package root run `python joss_review/check_evidence.py` (standard library). It checks all 378 archived pointwise records, the reported certificate threshold, observed label equality, coverage counts, six paired CSVs, manifest invariants, 60 sweep rows and Figure 1 checksum. Original embeddings and centroids are absent; slack is checked against the stored threshold, not independently recomputed from those embeddings.

For the separate reference calculation use Python with `joss_review/reference_requirements.txt`. Run `python joss_review/reference_identity_test.py` with BLAS and OpenMP threads set to 1 if possible. It constructs 240 deterministic synthetic scenarios, varying participation floors, availability, noise and view dropout. Some reference partitions are assigned by construction, others by seeded K-means; nearest-centroid consistency is asserted before the refit. It independently computes the mathematical drift, centroid bounds and certificate, and compares actual reassignment after one refit. Results in `joss_review/reference_identity_result.json`. This is not the BARG-CC engine or a semantic benchmark. The 240 scenarios are artificial and not independent real-world subjects. V8 did not rerun the upstream engine. The current repository could not be fetched from the execution environment.

## Revision 10: archive linkage
Studio DOI: https://doi.org/10.5281/zenodo.24528136; Agentic RAG DOI: https://doi.org/10.5281/zenodo.24528059. Both are author-supplied. Run `python joss_review/verify_archive_dois.py` to collect metadata, then manually compare the version-specific record and archived source with the tested commit and patch. Do not substitute RAG for the numerical engine.
