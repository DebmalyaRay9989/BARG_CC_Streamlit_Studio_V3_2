"""Check archived evidence only; does not rerun the clustering engine."""
from pathlib import Path
import csv, hashlib, collections, math
root=Path(__file__).resolve().parents[1]
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rows(p):
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
a=root/'docs/figure_sources/workflow_v6_supplied.png'; b=root/'paper/figures/workflow.png'
assert digest(a)==digest(b)
print('Figure 1 exact PNG SHA-256:',digest(a))
sweep=rows(root/'validation/certificate_firing/sweep.csv'); assert len(sweep)==60
assert sum(int(r['false_cert']) for r in sweep)==0
assert math.isclose(max(float(r['max_drift_gap']) for r in sweep),4.767020111984266e-15,rel_tol=1e-9)
counts=collections.defaultdict(lambda:[0,0])
for r in sweep:
    k=(r['dataset'],float(r['floor'])); counts[k][0]+=int(r['cert_affected_n']); counts[k][1]+=int(r['affected'])
for key,value in sorted(counts.items()):print(key, f'{value[0]}/{value[1]}')
for key,expected in [(('Digits fold',.0001),[1,166]),(('Synthetic, one low-reliability view',.1),[33,140]),(('Synthetic, one low-reliability view',.0001),[44,140])]:assert counts[key]==expected
v=root/'validation/public_commit_a213cd6'; files=sorted((v/'run1').glob('*.csv')); assert len(files)==6
for f in files:assert digest(f)==digest(v/'run2'/f.name)
print('Six archived CSV pairs byte-identical.')
for path,n,affected,cert,unchanged in [(root/'validation/digits_coverage.csv',360,29,85.55555555555556,99.44444444444444),(v/'run1/coverage.csv',18,6,66.66666666666666,100.)]:
    d={r['group']:r for r in rows(path)}; allr=d['All records']; ar=d['View removed']; assert int(allr['n'])==n and int(ar['n'])==affected and float(ar['certified_pct'])==0
    assert math.isclose(float(allr['certified_pct']),cert) and math.isclose(float(allr['unchanged_pct']),unchanged)
    print(path.name, n, affected, cert, unchanged)
print('Archived numerical evidence checks passed; no engine rerun.')
