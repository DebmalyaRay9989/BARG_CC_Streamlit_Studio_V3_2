"""Generate the exact, code-checked scientific workflow as vector and 600 dpi PNG."""
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
plt.rcParams.update({'font.family':'DejaVu Sans','mathtext.fontset':'dejavusans','pdf.fonttype':42,'svg.fonttype':'none'})
fig,ax=plt.subplots(figsize=(9.6,6.85)); fig.subplots_adjust(0,0,1,1); ax.set(xlim=(0,960),ylim=(0,685)); ax.axis('off')
navy='#183a51'; slate='#435b6b'; teal='#166b62'; blue='#255b91'; pale='#edf4f8'; mint='#e9f5f0'; white='#ffffff'; grey='#f1f3f4'
def panel(x,y,w,h,num,title,lines,edge=navy,fill=pale):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0,rounding_size=7',linewidth=1.15,facecolor=fill,edgecolor=edge,zorder=2))
    ax.add_patch(FancyBboxPatch((x+11,y+h-30),25,21,boxstyle='round,pad=0,rounding_size=4',linewidth=0,facecolor=edge,zorder=3))
    ax.text(x+23.5,y+h-19.5,num,ha='center',va='center',fontsize=10,color=white,fontweight='bold',zorder=4)
    ax.text(x+44,y+h-19.5,title,ha='left',va='center',fontsize=12,fontweight='bold',color=edge,zorder=4)
    ax.plot([x+11,x+w-11],[y+h-37]*2,color=edge,alpha=.3,lw=.7,zorder=3)
    pos=y+h-51
    for line in lines:
        text,size,spacing=line
        ax.text(x+13,pos,text,ha='left',va='top',fontsize=size,color='#172e3b',zorder=4)
        pos-=spacing
    assert pos>=y-4,(title,pos,y)
def arrow(points, color=slate):
    for p,q in zip(points[:-2],points[1:-1]): ax.plot([p[0],q[0]],[p[1],q[1]],color=color,lw=1.2,zorder=1)
    ax.add_patch(FancyArrowPatch(points[-2],points[-1],arrowstyle='-|>',mutation_scale=10,lw=1.2,color=color,shrinkA=0,shrinkB=0,zorder=1))
ax.text(12,672,'BARG-CC  /  SCIENTIFIC AUDIT WORKFLOW',fontsize=9.5,fontweight='bold',color=slate,va='center')
ax.text(948,672,'Streamlit V3.2 + manifest patch',fontsize=9.2,color=slate,ha='right',va='center')
panel(12,494,298,160,'1','Prepare inputs',[
 ('View blocks with different dimensions',9.5,16),
 (r'$m_{iv}\in\{0,1\},\quad r_{iv}\in[0,1]$',11,20),
 ('Reject all-missing rows; unit-normalize.',9.4,16),
 (r'$s_i\geq1,\quad\|e_{iv}\|_2=1$ (observed)',10.8,20),
 ('Record seed, hash and gate settings.',9.4,15)])
panel(331,494,298,160,'2','Fuse views',[
 (r'$\alpha_{iv}\propto m_{iv}\exp[\kappa(2r_{iv}-1)]$',10.7,21),
 (r'Weights sum to 1; $\kappa=0$: uniform',10.1,18),
 (r'Choose $\kappa$ for participation floor $\rho$.',10,18),
 (r'$z_i=\mathrm{concat}_v(\sqrt{\alpha_{iv}}\,e_{iv})$',11.6,22),
 ('Disjoint blocks; absent weights are 0.',9.4,14)])
panel(650,494,298,160,'3','Reference partition',[
 ('Seeded K-means; matched settings.',9.4,17),
 ('Select document K by silhouette.',9.4,17),
 (r'$C_k=\{i:y_i=k\}$; nonempty clusters',10.5,20),
 (r'$\mu_k=\mathrm{mean}_{i\in C_k}(z_i)$',11.1,22),
 ('Check nearest-centroid consistency.',9.2,14)])
arrow([(310,574),(331,574)]); arrow([(629,574),(650,574)])
panel(95,374,770,91,'4','Controlled view loss',[
 (r'Seeded removal: choose eligible rows ($s_i>1$); remove one observed view; retain at least one.',10.2,17),
 (r'Hold $e_{iv}$, $r_{iv}$ and $\kappa$ fixed; recompute $z_i^\prime$ on the reduced mask. Retain reference memberships.',10.2,17)],fill=grey)
arrow([(799,494),(799,479),(480,479),(480,465)])
panel(12,134,456,211,'5a','Conditional certificate',[
 (r'$q_i$: original weight of removed view (0 if none)',10.4,20),
 (r'$d_i=\sqrt{2(1-\sqrt{1-q_i})}$; check $\|z_i^\prime-z_i\|_2=d_i$',11.5,31),
 (r'$B_k=\mathrm{mean}_{i\in C_k}(d_i)$  (centroid budget)',10.9,22),
 (r'$g_{ik}=\|z_i-\mu_k\|_2-\|z_i-\mu_{y_i}\|_2$',11.2,23),
 (r'$\ell_i=\mathrm{min}_{k\ne y_i}\{g_{ik}-2d_i-B_{y_i}-B_k\}$',11.3,24),
 (r'Certify if $\ell_i>10^{-10}$ (implementation tolerance).',10.2,19),
 ('Otherwise: uncertified, not necessarily changed.',9.5,15)],edge=teal,fill=mint)
panel(492,134,456,211,'5b','Observed stability',[
 ('Refit centroids once, holding reference memberships fixed.',9.7,20),
 (r'$\mu_k^\prime=\mathrm{mean}_{i\in C_k}(z_i^\prime)$',12,25),
 ('Reassign by nearest refitted centroid (no further iterations).',9.6,19),
 (r'$y_i^\prime=\mathrm{argmin}_k\|z_i^\prime-\mu_k^\prime\|_2$',12,25),
 (r'$u_i=\mathbf{1}[y_i^\prime=y_i]$  (observed unchanged)',11.5,22),
 ('Check every certified record is unchanged.',9.8,20),
 ('A failed consistency check raises an error.',9.6,15)],edge=blue,fill=pale)
arrow([(480,374),(480,359),(240,359),(240,345)]); arrow([(480,374),(480,359),(720,359),(720,345)])
panel(12,22,936,83,'6','Reproducible evidence',[
 ('Coverage: all / view removed / no view removed; report certificate rate, unchanged rate and false-certificate count.',10.1,16),
 ('CSV: assignments, K diagnostics, exclusions, pointwise audit, coverage. JSON: seed, profile, input SHA-256 and configuration.',9.8,15)],fill=grey)
arrow([(240,134),(240,119),(480,119),(480,105)]); arrow([(720,134),(720,119),(480,119),(480,105)])
ax.text(480,8,'Sufficient certificate for a prescribed one-refit audit; not a guarantee for unrestricted reclustering or changing encoders.',ha='center',va='center',fontsize=9.1,fontweight='bold',color=navy)
out=Path(__file__).resolve().parent
for fmt in ('pdf','svg','png'): fig.savefig(out/f'workflow.{fmt}',dpi=600 if fmt=='png' else 200,facecolor='white')
