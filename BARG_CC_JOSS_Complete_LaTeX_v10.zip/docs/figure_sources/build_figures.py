"""Rebuild the paper figures from a diagram specification and archived sweep CSV.
Run from any directory with matplotlib and pandas installed. No models are run.
"""
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'paper' / 'figures'
OUT.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'mathtext.fontset':'dejavusans',
                     'pdf.fonttype':42,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False})
NAVY='#213B50'; TEAL='#216C65'; SLATE='#3D505C'; PALE='#F2F5F7'; MINT='#EAF4F1'; WHITE='#FFFFFF'

def save(fig, stem):
    for ext in ('pdf','svg','png'):
        fig.savefig(OUT/f'{stem}.{ext}',dpi=450 if ext=='png' else 180,facecolor='white')
    plt.close(fig)

fig,ax=plt.subplots(figsize=(7.1,3.75));fig.subplots_adjust(0,0,1,1)
ax.set(xlim=(0,710),ylim=(0,375)); ax.axis('off')
def box(x,y,w,h,title,lines,edge=NAVY,fill=PALE):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0,rounding_size=5',facecolor=fill,edgecolor=edge,lw=.9,zorder=2))
    ax.text(x+10,y+h-12,title,va='top',fontweight='bold',fontsize=10.7,color=edge,zorder=3)
    for i,line in enumerate(lines):
        ax.text(x+10,y+h-32-i*15,line,va='top',fontsize=9.25,color=SLATE,zorder=3)
def arrow(p,q):
    ax.add_patch(FancyArrowPatch(p,q,arrowstyle='-|>',mutation_scale=10,linewidth=1.0,color=SLATE,shrinkA=0,shrinkB=0,zorder=1))
def line(*points):
    ax.plot(*zip(*points),color=SLATE,lw=1,zorder=1)
box(5,289,218,78,'1  Prepare views',['Mask missing observations','Normalize observed blocks','Reject all-missing records'])
box(246,289,218,78,'2  Fuse views',['Bounded reliability weights','Uniform comparator at '+r'$\kappa=0$','Weighted block concatenation'])
box(487,289,218,78,'3  Reference partition',['Seeded K-means','Matched settings','Check centroid consistency'])
arrow((223,328),(246,328));arrow((464,328),(487,328))
box(87,211,536,53,'4  Controlled view loss',['Seeded removal; retain one or more views; freeze embeddings, scores and gate.'])
line((596,289),(596,277),(355,277));arrow((355,277),(355,264))
box(5,91,339,93,'5a  Conditional certificate',[r'Compute exact drift $d_i$ and centroid budgets $B_k$.',r'Compute lower margin $\ell_i$ from the reference.',r'Certify if $\ell_i>10^{-10}$; otherwise, uncertified.'],TEAL,MINT)
box(366,91,339,93,'5b  Observed stability',[r'Refit centroids once with memberships fixed.',r'Reassign to the nearest refitted centroid.',r'Check that every certified assignment persists.'])
line((355,211),(355,197),(174,197));arrow((174,197),(174,184));line((355,197),(535,197));arrow((535,197),(535,184))
box(5,21,700,50,'6  Reproducible evidence',['CSV: record-level audit and subgroup coverage. JSON: input hash, seed and settings.'])
line((174,91),(174,78),(355,78));line((535,91),(535,78),(355,78));arrow((355,78),(355,71))
ax.text(355,5,'Scope: fixed-membership, one-refit audit; not unrestricted reclustering.',ha='center',va='bottom',fontsize=9.1,fontweight='bold',color=NAVY)
plt.close(fig)  # Historical V3 diagram; selected V4 workflow is prepared separately.
import subprocess, sys
subprocess.run([sys.executable, str(ROOT/'docs/figure_sources/prepare_selected_workflow.py')],check=True)

p=pd.read_csv(ROOT/'validation/certificate_firing/sweep.csv')
assert len(p)==60 and p['false_cert'].sum()==0
summary=(p.groupby(['dataset','floor'],as_index=False).agg(affected=('affected','sum'),certified=('cert_affected_n','sum')))
summary['certified_pct']=100*summary.certified/summary.affected
summary.to_csv(ROOT/'docs/figure_sources/sweep_pooled.csv',index=False,float_format='%.8f')
fig,ax=plt.subplots(figsize=(6.8,2.75));fig.subplots_adjust(left=.12,right=.98,bottom=.25,top=.90)
for name,color,marker,ls,label in [('Synthetic, one low-reliability view',TEAL,'o','-','Synthetic mechanism test (n = 140 per floor)'),('Digits fold',NAVY,'s','--','Digits fold (n = 166 per floor)')]:
    s=summary[summary.dataset==name].sort_values('floor',ascending=False)
    ax.plot(s.floor,s.certified_pct,marker=marker,ls=ls,color=color,linewidth=1.7,markersize=5,label=label)
ax.set_xscale('log');ax.invert_xaxis();ax.set_ylim(-2,39);ax.set_yticks([0,10,20,30])
ax.set_xticks([.1,.03,.01,.003,.001,.0001],['0.1','0.03','0.01','0.003','0.001','0.0001'])
ax.set_xlabel(r'Requested participation floor $\rho$');ax.set_ylabel('Affected records\ncertified (%)')
ax.grid(axis='y',color='#DCE3E6',linewidth=.7);ax.set_axisbelow(True)
ax.legend(loc='upper center',bbox_to_anchor=(.5,1.18),ncol=2,frameon=False,fontsize=8.1,columnspacing=1.2,handlelength=2)
ax.annotate('33/140',(.1,100*33/140),xytext=(5,7),textcoords='offset points',fontsize=8.5,color=TEAL)
ax.annotate('44/140',(.0001,100*44/140),xytext=(-5,6),ha='right',textcoords='offset points',fontsize=8.5,color=TEAL)
ax.annotate('1/166',(.0001,100/166),xytext=(-4,6),ha='right',textcoords='offset points',fontsize=8.5,color=NAVY)
save(fig,'certificate_coverage')
