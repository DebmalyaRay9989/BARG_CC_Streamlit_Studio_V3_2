"""Preserve the selected generated illustration; correct narrowly scoped labels.
No scientific calculations are run. The source raster is archived alongside this script.
"""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
from matplotlib.mathtext import math_to_image
from matplotlib.font_manager import FontProperties
from io import BytesIO
ROOT = Path(__file__).resolve().parents[2]
im = Image.open(ROOT/'docs/figure_sources/workflow_selected.png').convert('RGB')
draw = ImageDraw.Draw(im)

def formula(rect, tex, bg, size=20):
    x0,y0,x1,y1=rect
    draw.rounded_rectangle(rect,radius=10,fill=bg)
    buf=BytesIO(); math_to_image('$'+tex+'$',buf,prop=FontProperties(size=size),dpi=150,format='png',color='#101719')
    buf.seek(0); f=Image.open(buf).convert('RGBA')
    # Matplotlib math_to_image emits white background; convert brightness into alpha.
    import numpy as np
    a=np.asarray(f).copy(); alpha=255-a[:,:,:3].min(axis=2); a[:,:,:3]=[16,23,25]; a[:,:,3]=alpha
    f=Image.fromarray(a); f.thumbnail((x1-x0-12,y1-y0-5),Image.Resampling.LANCZOS)
    im.paste(f,(x0+(x1-x0-f.width)//2,y0+(y1-y0-f.height)//2),f)
formula((453,527,689,574),r'd_i=\sqrt{2(1-\sqrt{1-q_i})}', '#dcefe8')
draw.rectangle((831,505,1490,572),fill='#eaf3fb')
heading=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',18)
draw.ellipse((840,514,849,523),fill='#101719')
draw.text((868,505),'Refit centroids once using fixed reference memberships:',font=heading,fill='#101719')
formula((978,527,1344,571),r"\mu'_k=\frac{1}{|C_k|}\sum_{i\in C_k}z'_i,\quad k=1,\ldots,K", '#e7f1fb')
# Change the conceptual export to the actual archived export scope.
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',15)
bold=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',15)
draw.rectangle((1007,835,1496,924),fill='#edf4fa')
for y,txt,ft in [(837,'– CSV: record ID, removed mass, exact/measured drift,',font),(855,'   slack, certification, original/refitted labels, unchanged.',font),(873,'– JSON manifest: seed, input SHA-256, run settings,',font),(891,'   Python/platform; source commit tracked separately.',font),(909,'   Centroid budgets are internal, not CSV fields.',font)]:
    draw.text((1010,y),txt,font=ft,fill='#101719')
im.save(ROOT/'paper/figures/workflow.png')
im.save(ROOT/'paper/figures/workflow.pdf',resolution=220.0)
