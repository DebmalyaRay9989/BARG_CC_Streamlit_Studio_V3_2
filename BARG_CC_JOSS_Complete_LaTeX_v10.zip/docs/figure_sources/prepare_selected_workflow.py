"""Embed the exact user-supplied Figure 1; no label edits or resampling."""
from pathlib import Path
import shutil
from PIL import Image
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader
root=Path(__file__).resolve().parents[2]
src=root/'docs/figure_sources/workflow_v7_supplied.png'
out=root/'paper/figures'
out.mkdir(parents=True,exist_ok=True)
shutil.copyfile(src,out/'workflow.png')
with Image.open(src) as im:
    w,h=im.size
    c=canvas.Canvas(str(out/'workflow.pdf'),pagesize=(w,h),invariant=1)
    c.drawImage(ImageReader(im),0,0,width=w,height=h,mask='auto')
    c.showPage(); c.save()
