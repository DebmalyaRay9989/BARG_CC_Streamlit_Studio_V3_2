"""Regenerate the LaTeX companion from canonical JOSS Markdown."""
from pathlib import Path
import subprocess
root=Path(__file__).resolve().parents[1]
body=subprocess.check_output(['pandoc','--from=markdown','--to=latex','--biblatex','--no-highlight','paper/paper.md'],cwd=root,text=True)
body=body.replace(r'\begin{figure}',r'\begin{figure}[H]')
body=body.replace(r'width=1\textwidth,height=\textheight',r'width=\linewidth,keepaspectratio')
for stem in ('workflow','certificate_coverage'):
    body=body.replace(f'figures/{stem}.png',f'figures/{stem}.pdf')
body=body.replace(r'\includegraphics[width=\linewidth,keepaspectratio]{figures/workflow.pdf}',r'\includegraphics[width=5.65in,keepaspectratio]{figures/workflow.pdf}')
body=body.replace(r'\includegraphics[width=\linewidth,keepaspectratio]{figures/certificate_coverage.pdf}',r'\includegraphics[width=0.72\linewidth,keepaspectratio]{figures/certificate_coverage.pdf}')
# Companion-specific page breaks; official JOSS renderer controls its own layout.
for heading in (r'\section{Software design}',r'\subsection{Bounded reliability',r'\section{Research impact statement}',r'\section{AI usage disclosure}'):
    body=body.replace(heading,r'\clearpage'+'\n'+heading)
(root/'latex/manuscript.tex').write_text(body)
