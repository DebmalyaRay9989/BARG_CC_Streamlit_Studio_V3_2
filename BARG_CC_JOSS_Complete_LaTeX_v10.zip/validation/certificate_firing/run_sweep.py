"""Where does the one-refit certificate fire on records that lost a view?

Uses the public BARG-CC Streamlit engine unchanged (view_loss_audit, digits_demo,
strength_for_floor). Usage: python run_sweep.py /path/to/BARG_CC_Streamlit_Studio_V3_2 out.csv
Synthetic data are a controlled mechanism test, not a benchmark.
"""
import sys, csv
root, out = sys.argv[1], sys.argv[2]
sys.path.insert(0, root)
import numpy as np
from sklearn.preprocessing import normalize
from engine import view_loss_audit, digits_demo
from hamv_gate import strength_for_floor

def summarize(df):
    a = df[df.dropped]; u = df[~df.dropped]
    return dict(n=len(df), affected=len(a),
                cert_all=100*df.certified.mean(),
                cert_affected=100*a.certified.mean() if len(a) else float('nan'),
                cert_affected_n=int(a.certified.sum()),
                unchanged_affected=100*a.unchanged.mean() if len(a) else float('nan'),
                false_cert=int((df.certified & ~df.unchanged).sum()),
                max_drift_gap=float((df.exact_drift-df.measured_drift).abs().max()))

def synthetic(seed, floor, unreliable_r=0.05, n=300, k=3, sep=3.0, noise=0.35):
    """3 views of k well-separated clusters; view 3 is low-reliability for every record."""
    rng = np.random.default_rng(seed)
    y = rng.integers(0, k, n); centers = rng.normal(size=(k, 6)) * sep
    views = [normalize(centers[y] + rng.normal(0, noise, (n, 6)) * (1 + .1*j)) for j in range(3)]
    r = np.column_stack([rng.uniform(.85, 1, n), rng.uniform(.85, 1, n), np.full(n, unreliable_r)])
    mask = np.ones((n, 3), bool)
    kappa = strength_for_floor(floor, 3)
    return view_loss_audit(views, mask, r, kappa, k, seed, 0.1), kappa

rows = []
for floor in [0.1, 0.03, 0.01, 0.003, 0.001, 0.0001]:
    kappa = strength_for_floor(floor, 3)
    for seed in [17, 18, 19, 20, 21]:
        d = digits_demo(kappa, 0.1, seed)
        rows.append(dict(dataset='Digits fold', floor=floor, kappa=round(kappa, 3), seed=seed, **summarize(d)))
        s, kappa = synthetic(seed, floor)
        rows.append(dict(dataset='Synthetic, one low-reliability view', floor=floor, kappa=round(kappa, 3), seed=seed, **summarize(s)))
with open(out, 'w', newline='') as f:
    w = csv.DictWriter(f, fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
print('rows', len(rows))
