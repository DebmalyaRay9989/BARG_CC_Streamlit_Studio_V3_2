# BARG-CC — complete LaTeX companion (v10)

Upload the ZIP to Overleaf, set `main.tex` as the main document, and choose XeLaTeX with Biber. Alternatively extract and run `BUILD_LATEX.cmd` on Windows or `bash build_latex.sh` on Linux/macOS with a current TeX distribution. Libertinus and Latin Modern fonts are provided by TeX Live; font files are not bundled. The included PDF is a compiled companion preview, not official JOSS typesetting.

- `paper/paper.md` and `paper/paper.bib`: canonical JOSS manuscript and bibliography.
- `main.tex`, `latex/manuscript.tex`: complete editable companion source.
- `paper/figures/workflow.png`: exact supplied artwork (674 × 761), with a lossless PDF wrapper for LaTeX.
- `paper/figures/certificate_coverage.*`: Figure 2, calculated from the archived sweep CSV.
- `python latex/regenerate.py`: regenerate LaTeX body from Markdown (Pandoc required).
- `python docs/figure_sources/build_figures.py`: regenerate figure assets (matplotlib, pandas, Pillow, ReportLab). No scientific engine runs.
- `python joss_review/check_evidence.py`: verify exact Figure 1 hash equality, archived CSV statistics and batch CSV repeatability (standard Python library).

See `README_SUBMISSION.md` for remaining author and repository checks. The two supplied archive DOIs are cited provisionally; their version metadata and source equivalence remain unverified. Official JOSS compilation and remote repository updates are not claimed.
