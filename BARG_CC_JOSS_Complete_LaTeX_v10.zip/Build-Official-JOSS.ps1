param([string]$PaperDir = (Join-Path $PSScriptRoot 'paper'))
$ErrorActionPreference = 'Stop'
if (-not (Get-Command docker -ErrorAction SilentlyContinue)) { throw 'Install and start Docker Desktop first.' }
$path = (Resolve-Path $PaperDir).Path
if (-not (Test-Path (Join-Path $path 'paper.md'))) { throw 'paper.md not found' }
# Work in a temporary copy to avoid treating an old PDF as a successful new build.
$temp = Join-Path ([System.IO.Path]::GetTempPath()) ('barg-joss-' + [guid]::NewGuid())
New-Item -ItemType Directory $temp | Out-Null
Copy-Item (Join-Path $path '*') $temp -Recurse
Remove-Item (Join-Path $temp 'paper.pdf') -ErrorAction SilentlyContinue
try {
    docker run --rm --volume "${temp}:/data" --env JOURNAL=joss openjournals/inara
    if ($LASTEXITCODE -ne 0) { throw 'Official compiler failed.' }
    $pdf = Join-Path $temp 'paper.pdf'
    if (-not (Test-Path $pdf)) { throw 'Compiler did not produce paper.pdf.' }
    Copy-Item $pdf (Join-Path $path 'paper.pdf') -Force
    Get-FileHash (Join-Path $path 'paper.pdf') -Algorithm SHA256
} finally { Remove-Item $temp -Recurse -Force }
