@echo off
setlocal
cd /d "%~dp0"
xelatex -interaction=nonstopmode -halt-on-error main.tex || exit /b 1
biber main || exit /b 1
xelatex -interaction=nonstopmode -halt-on-error main.tex || exit /b 1
xelatex -interaction=nonstopmode -halt-on-error main.tex || exit /b 1
echo Build completed: main.pdf
