param([string]$Repository = 'DebmalyaRay9989/BARG_CC_Streamlit_Studio_V3_2', [string]$Output = (Join-Path $PSScriptRoot 'live-history'))
$ErrorActionPreference = 'Stop'
New-Item -ItemType Directory -Force $Output | Out-Null
$headers = @{ Accept = 'application/vnd.github+json'; 'X-GitHub-Api-Version' = '2022-11-28' }
$base = "https://api.github.com/repos/$Repository"
$meta = Invoke-RestMethod $base -Headers $headers
$meta | ConvertTo-Json -Depth 20 | Set-Content (Join-Path $Output 'repo.json') -Encoding UTF8
if ($meta.private) { throw 'Repository is not public.' }
function Save-Pages($endpoint, $name) {
  $all = @(); $page = 1
  do {
    $batch = @(Invoke-RestMethod "${endpoint}?per_page=100&page=$page" -Headers $headers)
    $all += $batch; $page++
  } while ($batch.Count -eq 100)
  ConvertTo-Json -InputObject $all -Depth 30 | Set-Content (Join-Path $Output "$name.json") -Encoding UTF8
  return ,$all
}
$commits = Save-Pages "$base/commits" 'commits'
$releases = Save-Pages "$base/releases" 'releases'
$tags = Save-Pages "$base/tags" 'tags'
# issues endpoint has its own query string; capture all states with explicit pagination
$issues = @(); $page = 1
 do { $batch = @(Invoke-RestMethod "$base/issues?state=all&per_page=100&page=$page" -Headers $headers); $issues += $batch; $page++ } while ($batch.Count -eq 100)
ConvertTo-Json -InputObject $issues -Depth 30 | Set-Content (Join-Path $Output 'issues-and-prs.json') -Encoding UTF8
$dates = @($commits | ForEach-Object { [datetimeoffset]$_.commit.committer.date } | Sort-Object)
$summary = [ordered]@{ checked_utc = [datetimeoffset]::UtcNow.ToString('o'); repository = $Repository; created_at = $meta.created_at; visibility = $meta.visibility; commits = $commits.Count; releases = $releases.Count; tags = $tags.Count; issues_and_prs = $issues.Count; earliest_commit = $(if($dates.Count){$dates[0].ToString('o')}); latest_commit = $(if($dates.Count){$dates[-1].ToString('o')}); warning = 'Creation and commit timestamps alone do not prove continuous public visibility. Supply authentic public release, issue, PR and usage evidence.' }
$summary | ConvertTo-Json | Set-Content (Join-Path $Output 'summary.json') -Encoding UTF8
$summary
