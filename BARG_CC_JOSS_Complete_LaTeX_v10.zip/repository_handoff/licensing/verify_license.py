"""Read-only check of public GitHub root MIT license; does not prove ownership."""
import argparse, base64, hashlib, json, re, sys
from datetime import datetime, timezone
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.parse import quote
from urllib.error import HTTPError, URLError

def fetch(url):
    req = Request(url, headers={'Accept':'application/vnd.github+json','User-Agent':'BARG-CC-JOSS-license-audit','X-GitHub-Api-Version':'2022-11-28'})
    with urlopen(req, timeout=20) as response:
        return json.load(response)

def normalize(s):
    return ' '.join(s.split())

def check_body(content, template):
    text = content.decode('utf-8-sig')
    marker = 'Permission is hereby granted'
    if marker not in text or '[' in text.split(marker)[0] or not re.search(r'Copyright\s*(?:\(c\)|©)?\s*\d{4}[^\n]*\S',text.split(marker)[0],re.I):
        return False
    return normalize(text.split(marker,1)[1]) == normalize(template.split(marker,1)[1])

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo',default='DebmalyaRay9989/BARG_CC_Streamlit_Studio_V3_2')
    parser.add_argument('--output',default='license-evidence.json')
    args=parser.parse_args()
    if not re.fullmatch(r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+',args.repo): parser.error('expected owner/repository')
    base='https://api.github.com/repos/'+args.repo
    result={'repository':args.repo,'checked_utc':datetime.now(timezone.utc).isoformat(),'status':'UNVERIFIED','scope':'Public default-branch commit and MIT text only; does not establish rights-holder consent or third-party rights.'}
    try:
        meta=fetch(base)
        result['private']=meta['private']; result['default_branch']=meta['default_branch']
        if meta['private']: raise ValueError('Repository is not public')
        commit=fetch(base+'/commits/'+quote(meta['default_branch'],safe=''))['sha']; result['commit']=commit
        info=fetch(base+'/license?ref='+commit)
        result['path']=info['path']; result['spdx']=(info.get('license') or {}).get('spdx_id')
        if info.get('encoding')!='base64': raise ValueError('Unsupported license content encoding')
        content=base64.b64decode(info['content']); result['sha256']=hashlib.sha256(content).hexdigest()
        template=Path(__file__).with_name('LICENSE-MIT-DRAFT.txt').read_text(encoding='utf-8')
        if result['path']!='LICENSE' or result['spdx']!='MIT' or not check_body(content,template):
            result['status']='REVIEW_REQUIRED'; result['reason']='Expected root LICENSE and complete MIT text with non-placeholder copyright. A different OSI license may be valid; review manually.'
        else:
            result['status']='MIT_TEXT_VERIFIED'; result['license_url']=f'https://github.com/{args.repo}/blob/{commit}/LICENSE'
    except (HTTPError,URLError,TimeoutError,ValueError,KeyError,OSError) as e:
        result['reason']=str(e)
    Path(args.output).write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2)); return 0 if result['status']=='MIT_TEXT_VERIFIED' else 1
if __name__=='__main__': sys.exit(main())
