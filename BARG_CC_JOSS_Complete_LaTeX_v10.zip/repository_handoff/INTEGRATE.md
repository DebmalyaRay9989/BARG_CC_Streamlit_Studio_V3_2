# Repository handoff (not yet applied)

Use the scientific Streamlit source repository, not the Agentic RAG repository, as the primary JOSS submission candidate. Make a real review branch; avoid force pushes or manufactured history. This handoff assumes the same file structure as the public main branch inspected on 25 November 2026.

1. Extract the manuscript ZIP. Set `$package` to its absolute extracted path. In a separate PowerShell terminal, clone the primary repository, inspect its current state, and create a review branch.

```powershell
$package = Read-Host 'Absolute path to extracted manuscript package'
git clone https://github.com/DebmalyaRay9989/BARG_CC_Streamlit_Studio_V3_2.git
Set-Location BARG_CC_Streamlit_Studio_V3_2
git switch -c joss-review
git status
git rev-parse HEAD
```

2. Ensure the current working tree is clean and no existing manuscript is overwritten unintentionally. Check the public-repository patch before applying it; if the upstream file has changed, reconcile manually instead of replacing unrelated code.

```powershell
git apply --check "$package/patch/public_repo_fixes.patch"
if ($LASTEXITCODE -ne 0) { throw 'Review current run_batch.py and Streamlit config before applying the patch' }
git apply "$package/patch/public_repo_fixes.patch"
if (Test-Path paper) { throw 'Review existing paper folder before copying' }
Copy-Item "$package/paper" . -Recurse
New-Item -ItemType Directory -Force joss_verification | Out-Null
Copy-Item "$package/docs/verify_workflow.py" joss_verification/
Copy-Item "$package/joss_review/reference_identity_test.py" joss_verification/
```

3. In an isolated environment with dependencies installed, run the following. The first command installs declared dependencies, the next two execute checks; do not claim success unless they actually pass.

```powershell
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
python joss_verification/verify_workflow.py .
python joss_verification/reference_identity_test.py
```

4. Optional CI: copy the supplied workflow after reviewing existing workflows. This configuration is prepared, not remotely executed; successful CI requires testing against the actual repository.

```powershell
New-Item -ItemType Directory -Force .github/workflows | Out-Null
Copy-Item "$package/repository_handoff/.github/workflows/joss-verification.yml" .github/workflows/
Copy-Item "$package/repository_handoff/.github/workflows/draft-pdf.yml" .github/workflows/
```

5. Confirm license/rights, research use, authorship/funding/disclosures and public development history. Funding is confirmed by the submitting user; obtain both authors’ final approval. Follow `licensing/README.md` for the proposed MIT license and verifier. Run the official JOSS compiler. Review diffs for secrets, unauthorized materials or unrelated changes; stage only reviewed files, commit, and open a genuine pull request if appropriate. Record the final commit and real release tags. Do not publish access tokens or confidential research data.

```powershell
git status
git diff --stat
git log --reverse --format="%h %ad %s" --date=short
```

See the parent `README_SUBMISSION.md` for mandatory eligibility checks. The patch was verified in the archived V7 evidence, not rerun in V8. The new reference calculation is executed locally; neither engine tests nor remote CI were rerun in V8. This handoff has not been applied to a remote clone. No license is granted by this package.
