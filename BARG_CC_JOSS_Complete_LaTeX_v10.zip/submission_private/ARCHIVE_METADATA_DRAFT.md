# Zenodo metadata — author-supplied identifiers; metadata verification pending

- Title: BARG-CC: Python software for reliability-aware multi-view clustering and reproducible stability audits
- Resource type: Software
- Creators: Debmalya Ray (International Institute of Information Technology Bangalore); Prodipto Das (Assam University), subject to software authorship approval
- Repository: https://github.com/DebmalyaRay9989/BARG_CC_Streamlit_Studio_V3_2
- Proposed version: v3.2.1 (example only; confirm actual unused tag and maintainer version scheme)
- License: pending rights-holder approval; use an OSI-approved license matching the actual repository LICENSE file. Do not assume the PyPI MIT license applies here.
- Description: Python research software for reliability-aware multi-view clustering, controlled view-loss audits, conditional stability certification under a single fixed-membership centroid refit, and reproducible batch evidence exports.
- Keywords: Python; multi-view clustering; reliability-aware fusion; stability certification; reproducible research.
- Funding: none, as confirmed by the submitting user on 25 November 2026; no grant metadata to enter. Final co-author review pending.
- Studio DOI supplied by author: https://doi.org/10.5281/zenodo.24528136. RAG DOI supplied by author: https://doi.org/10.5281/zenodo.24528059. Version/concept DOI classification, tag, commit, creators, license and archive contents remain unverified. Proposed version above is not a claim about either deposit.

Enable this repository at https://zenodo.org/account/settings/github/ before creating an authorized GitHub release. Confirm rights, metadata, exclusions and checksums; archive the actual reviewed software, not this manuscript handoff ZIP. A pre-review archive is optional; the final version-specific DOI must correspond to the version approved by JOSS at the end of review. Check the resolved record, version, creators, license and contents; add a bibliography entry and provide DOI to the editor. Do not use a concept DOI in place of the release DOI.
