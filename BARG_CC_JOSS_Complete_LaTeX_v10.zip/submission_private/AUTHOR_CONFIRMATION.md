# Private author confirmation — unsigned, not for public repository

Title: BARG-CC: Python software for reliability-aware multi-view clustering and reproducible stability audits

Please obtain actual approval from both listed authors. Do not publish this worksheet or enter private contact details in GitHub.

| Item | Debmalya Ray (IIIT Bangalore) | Prodipto Das (Assam University) |
|---|---|---|
| Software contribution (describe actual work) | Pending | Pending |
| Name, affiliation and ORCID if available | Pending | Pending |
| Approval of manuscript, figures and code | Pending | Pending |
| AI tools/versions, uses and human verification confirmed | Pending | Pending |
| Rights to distribute code, figures, example inputs and results | Pending | Pending |
| Agreement to software license | Pending | Pending |
| Agreement to author order and archive metadata | Pending | Pending |
| Date of approval | Pending | Pending |

Corresponding author: to confirm. Funding: the submitting user confirmed no funding on 25 November 2026; the manuscript has been updated. The co-author must still review the final declaration. Confirm acknowledgements and permissions for named contributors. Confirm any competing interests. Confirm Figure 1 provenance and the Claude attribution in the AI disclosure; correct uncertain tool details rather than assert them.

The manuscript now states “The authors received no funding for this work.” Reconcile any contrary information before submission. Do not sign or assert approval on someone else's behalf.
