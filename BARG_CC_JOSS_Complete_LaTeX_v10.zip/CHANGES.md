# Revision V8
- JOSS-focused revision of Summary, Statement of need, State of the field, Software design, Research impact statement and AI disclosure.
- Exact preservation of author-supplied Figure 1 and archived Figure 2. Figure 2 resized only for companion pagination.
- Added output-level audit and independent reference calculation with results and scope. No new software engine runs.
- Added reviewer readiness gate, private author/archival templates and updated repository handoff.
- Rebuilt LaTeX companion and Pandoc preflight. Eligibility, official rendering, rights and approvals remain open.

# Revision V9
- Recorded no funding as confirmed by submitting user on 25 Nov 2026 in paper and archive draft.
- Prepared MIT license candidate and commit-pinned read-only repository verification script; remote license and rights are not verified.
- Final author approval remains outstanding. No scientific results changed.

# Revision V10
- Integrated author-supplied Studio and RAG DOI identifiers and clarified review scope.
- Added read-only archive metadata verification and checklist; no archive identity, release version or license inferred.
- Rebuilt Markdown preflight and LaTeX companion; reran archived evidence and standalone mathematical checks. No upstream engine run.
