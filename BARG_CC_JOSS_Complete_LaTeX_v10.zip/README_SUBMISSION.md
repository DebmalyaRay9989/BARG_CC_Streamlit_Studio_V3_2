# BARG-CC V10 — JOSS review candidate (25 November 2026)

**Do not submit until the eligibility and author checks below are resolved.** The canonical manuscript is `paper/paper.md`, not the five-page companion PDF. This archive is a manuscript and verification handoff, not an archival release of the complete software. The scientific target is the offline batch audit in BARG-CC Streamlit Studio V3.2.

## Start here
1. Read `joss_review/READINESS.md`. Confirm repository eligibility before making a submission.
2. Review and execute `repository_handoff/INTEGRATE.md` against the actual primary GitHub repository. The overlay must be merged with the existing software rather than used as a standalone software repository. The patch targets the exact archived source commit; do not blindly apply it to changed files. Confirm author and third-party rights before uploading any files.
3. Read `docs/REPRODUCE.md` (historical and V8 checks). The V8 standalone archive audit and reference equation check can be run immediately from the package root:
   ```sh
   python joss_review/check_evidence.py
   python -m pip install -r joss_review/reference_requirements.txt
   python joss_review/reference_identity_test.py
   ```
4. Run full engine tests and CLI example in a fresh isolated environment; record commit, requirements, runtime and logs. Test on at least one other machine or via CI. Run the official JOSS GitHub Action or Windows Docker script `Build-Official-JOSS.ps1` (Docker not available in the V8 environment). `joss_review/preflight.html` and the companion PDF are local builds only.
5. Both authors must review the final paper and source, verify disclosure, funding, acknowledgements, contributions, rights, conflicts and affiliations. Use the unsigned private worksheet in `submission_private/`. Do not publish that worksheet or private contact information. No funding was confirmed by the submitting user on 25 Nov 2026 and is stated in the paper. Confirm the final declaration with the co-author, any contributor acknowledgements, and the reported Claude attribution/figure provenance. Add verified ORCID identifiers if available.
6. Follow `repository_handoff/licensing/README.md` for the MIT candidate and live license verifier. Verify genuine public history, OSI-approved root LICENSE, packaging, example data permissions, documentation, tests and community guidelines. Add a support/contact channel and contributor guidance appropriate to the project. Link existing genuine evidence of research use; do not manufacture issues, commits, adopters or releases.
7. When eligible, submit through https://joss.theoj.org/ using the primary repository and the canonical Markdown. Disclose the associated unpublished research manuscript and separate distributions as applicable. A final tagged software archive and version-specific DOI are normally requested at the end of successful review; see `submission_private/ARCHIVE_METADATA_DRAFT.md`.

## Changes in V10
- Added Studio and Agentic RAG Zenodo identifiers to canonical paper, bibliography and archival checklist. Both records could not be retrieved from DOI/DataCite endpoints; no release metadata has been invented. Confirm the Studio record is version-specific and contains the actual tested source before treating archival compliance as complete.
- Funding remains confirmed. Public development, rights and final author review remain unresolved.
- Run `python joss_review/verify_archive_dois.py` to retrieve public metadata and inspect release provenance.

## Changes in V8
- Revised JOSS narrative, build-versus-contribute justification, concrete research use and output interpretation; clarified arithmetic-mean/nearest-centroid premises.
- Preserved Figure 1 pixel-for-pixel and Figure 2 archived data. Five-page LaTeX companion rebuilt; Pandoc citation preflight executed. Official JOSS build not run.
- Added standard-library pointwise output validation for 378 records, manifest comparison and 60 sweep records. Added separate deterministic NumPy/scikit-learn mathematical reference check (240 scenarios; 11,520 record-instances). Results in `joss_review/`; neither is a new engine run.
- Updated repository integration and CI handoff with draft compiler workflow and reference test. No live GitHub modifications, license approval, DOI minting or author confirmation.

## Policy sources (checked 25 November 2026)
- https://joss.readthedocs.io/en/latest/paper.html
- https://joss.readthedocs.io/en/latest/submitting.html
- https://joss.readthedocs.io/en/latest/review_checklist.html
- https://joss.readthedocs.io/en/latest/review_criteria.html
- https://github.com/marketplace/actions/open-journals-pdf-generator
